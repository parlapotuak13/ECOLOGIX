<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/Models/StateModel.php';
require_once dirname(__DIR__) . '/Models/VendorModel.php';

class SystemController
{
    public static function updateObjectiveWeights(PDO $pdo, array $body, int $nowMs): array
    {
        $alpha = max(0, min(100, (int) ($body['alpha'] ?? 70)));
        $beta  = max(0, min(100, (int) ($body['beta'] ?? 30)));
        $upd = $pdo->prepare("UPDATE `system_state` SET `alpha` = ?, `beta` = ?, `vendor_sync_at` = ? WHERE `id` = 1");
        $upd->execute([$alpha, $beta, $nowMs]);
        return ['ok' => true, 'state' => StateModel::getFullState($pdo)];
    }

    public static function resetAll(PDO $pdo, int $nowMs): array
    {
        $initOtp = (string) random_int(1000, 9999);
        $pdo->beginTransaction();
        $pdo->exec("DELETE FROM `handover_logs`");
        $pdo->exec("DELETE FROM `vendor_history`");
        $pdo->exec("DELETE FROM `shipments`");

        $stmtShip = $pdo->prepare("
            INSERT INTO `shipments` (
              `id`, `user_id`, `sender`, `city`, `pickup_district`, `pickup_address`,
              `destination_district`, `destination_address`, `package_type`, `quantity`,
              `weight_kg`, `dim_l`, `dim_w`, `dim_h`, `volume_cm3`, `volume_liters`,
              `notes`, `mode`, `stage`, `otp`, `created_at`
            ) VALUES (
              'ELX-MLG01', 1, 'UMKM Kopi Malang', 'Kota Malang',
              'Lowokwaru', 'Jl. MT Haryono No. 45, Dinoyo',
              'Lowokwaru', 'Jl. Gajayana No. 18, Ketawanggede',
              'Paket kecil', 2, 3.50, 30.00, 20.00, 15.00, 18000.00, 18.00,
              'Kopi bubuk kemasan rapat', 'hijau', 0, ?, ?
            )
        ");
        $stmtShip->execute([$initOtp, $nowMs - 300000]);

        $updSt = $pdo->prepare("
            UPDATE `system_state`
            SET `courier` = 'a', `progress` = 0, `verified` = 0, `otp` = ?,
                `alpha` = 70, `beta` = 30, `selected_shipment_id` = 'ELX-MLG01',
                `vendor_sharing` = 1, `vendor_threshold` = 0.75, `vendor_detour` = 2.00,
                `vendor_area` = 1, `vendor_volume` = 1, `vendor_weight` = 1,
                `vendor_decision` = 'approved', `vendor_decided_at` = ?, `vendor_sync_at` = ?
            WHERE `id` = 1
        ");
        $updSt->execute([$initOtp, $nowMs, $nowMs]);

        VendorModel::addHistory($pdo, 'approved', $nowMs);
        $pdo->commit();

        return ['ok' => true, 'state' => StateModel::getFullState($pdo)];
    }
}
