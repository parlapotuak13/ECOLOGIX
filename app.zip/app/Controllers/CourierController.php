<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/Models/ShipmentModel.php';
require_once dirname(__DIR__) . '/Models/HandoverModel.php';
require_once dirname(__DIR__) . '/Models/StateModel.php';

class CourierController
{
    public static function updateCourierAndProgress(PDO $pdo, array $body, int $nowMs): array
    {
        $courier  = ($body['courier'] ?? 'a') === 'b' ? 'b' : 'a';
        $progress = max(0, min(100, (int) ($body['progress'] ?? 0)));
        $stage    = min(5, (int) floor($progress / 20));

        $pdo->beginTransaction();
        $upd = $pdo->prepare("UPDATE `system_state` SET `courier` = ?, `progress` = ?, `vendor_sync_at` = ? WHERE `id` = 1");
        $upd->execute([$courier, $progress, $nowMs]);

        $st = StateModel::getRow($pdo);
        $selId = $st ? (string) $st['selected_shipment_id'] : '';
        if ($selId !== '') {
            ShipmentModel::updateStage($pdo, $selId, $stage);
        }
        $pdo->commit();

        return ['ok' => true, 'state' => StateModel::getFullState($pdo)];
    }

    public static function verifyOtp(PDO $pdo, array $body, int $nowMs): array
    {
        $inputOtp = trim((string) ($body['otp'] ?? ''));
        $logText  = trim((string) ($body['logText'] ?? ''));
        $st       = StateModel::getRow($pdo);

        if (!$st || (string) $st['otp'] !== $inputOtp) {
            http_response_code(400);
            return ['ok' => false, 'error' => 'Kode OTP tidak sesuai.'];
        }

        $newProg  = max(60, (int) $st['progress']);
        $newStage = min(5, (int) floor($newProg / 20));
        $selId    = (string) $st['selected_shipment_id'];

        $pdo->beginTransaction();
        $upd = $pdo->prepare("UPDATE `system_state` SET `verified` = 1, `progress` = ?, `vendor_sync_at` = ? WHERE `id` = 1");
        $upd->execute([$newProg, $nowMs]);

        if ($selId !== '') {
            ShipmentModel::updateStage($pdo, $selId, $newStage);
        }
        if ($logText !== '') {
            HandoverModel::addLog($pdo, $selId, $inputOtp, $logText, $nowMs);
        }
        $pdo->commit();

        return ['ok' => true, 'state' => StateModel::getFullState($pdo)];
    }
}
