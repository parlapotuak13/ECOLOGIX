<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/Models/UserModel.php';
require_once dirname(__DIR__) . '/Models/StateModel.php';

class AuthController
{
    public static function handleLoginOrRegister(PDO $pdo, array $body, string $action, int $nowMs): array
    {
        $email      = strtolower(trim((string) ($body['email'] ?? '')));
        $pass       = (string) ($body['pass'] ?? '');
        $roleChoice = (string) ($body['roleChoice'] ?? 'pengirim');
        $inputName  = trim((string) ($body['name'] ?? ''));

        if ($email === '' || strlen($pass) < 4) {
            http_response_code(400);
            return ['ok' => false, 'error' => 'Email dan kata sandi (minimal 4 karakter) wajib diisi.'];
        }

        $roleMap = [
            'pengirim' => ['role' => 'pengirim', 'courierCode' => null, 'badge' => 'Pengirim'],
            'kurir_a'  => ['role' => 'kurir',    'courierCode' => 'a',  'badge' => 'Kurir · Eco Hemat'],
            'kurir_b'  => ['role' => 'kurir',    'courierCode' => 'b',  'badge' => 'Kurir · Kilat Raya'],
            'vendor'   => ['role' => 'vendor',   'courierCode' => null, 'badge' => 'Vendor 3PL'],
        ];
        $rm = $roleMap[$roleChoice] ?? $roleMap['pengirim'];

        $existing = UserModel::findByEmail($pdo, $email);
        $isDefaultSeed = ($pass === 'demo1234' && in_array($email, [
            'pengirim@umkm-malang.id',
            'kurir.a@ecohemat.id',
            'kurir.b@kilatraya.id',
            'admin@ecohemat-3pl.id',
        ], true));

        if ($existing) {
            if ($action === 'login' && !$isDefaultSeed && !password_verify($pass, (string) $existing['password_hash'])) {
                http_response_code(401);
                return ['ok' => false, 'error' => 'Kata sandi salah.'];
            }
            $displayName = $inputName !== '' ? $inputName : (string) $existing['name'];
            $newHash     = password_hash($pass, PASSWORD_BCRYPT);
            $userId      = (int) $existing['id'];
            UserModel::update($pdo, $userId, $displayName, $newHash, $rm['role'], $rm['courierCode'], $rm['badge']);
        } else {
            $displayName = $inputName !== '' ? $inputName : explode('@', $email)[0];
            $newHash     = password_hash($pass, PASSWORD_BCRYPT);
            $userId      = UserModel::create($pdo, $displayName, $email, $newHash, $rm['role'], $rm['courierCode'], $rm['badge']);
        }

        if ($rm['courierCode'] !== null) {
            $upd = $pdo->prepare("UPDATE `system_state` SET `courier` = ?, `vendor_sync_at` = ? WHERE `id` = 1");
            $upd->execute([$rm['courierCode'], $nowMs]);
        }

        $userData = [
            'id'          => $userId,
            'email'       => $email,
            'name'        => $displayName,
            'role'        => $rm['role'],
            'courierCode' => $rm['courierCode'],
            'badge'       => $rm['badge'],
        ];
        if (function_exists('setActiveSessionUser')) {
            setActiveSessionUser($userData);
        } else {
            $_SESSION['ecologix_user'] = $userData;
        }

        return ['ok' => true, 'state' => StateModel::getFullState($pdo)];
    }

    public static function handleLogout(PDO $pdo): array
    {
        if (function_exists('setActiveSessionUser')) { setActiveSessionUser(null); } else { unset($_SESSION['ecologix_user']); }
        return ['ok' => true, 'state' => StateModel::getFullState($pdo)];
    }
}
