<?php
declare(strict_types=1);

class UserModel
{
    public static function findByEmail(PDO $pdo, string $email): ?array
    {
        $stmt = $pdo->prepare("SELECT * FROM `users` WHERE `email` = ? LIMIT 1");
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(PDO $pdo, string $name, string $email, string $hash, string $role, ?string $courierCode, string $badge): int
    {
        $stmt = $pdo->prepare("
            INSERT INTO `users` (`name`, `email`, `password_hash`, `role`, `courier_code`, `badge`)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$name, $email, $hash, $role, $courierCode, $badge]);
        return (int) $pdo->lastInsertId();
    }

    public static function update(PDO $pdo, int $id, string $name, string $hash, string $role, ?string $courierCode, string $badge): void
    {
        $stmt = $pdo->prepare("
            UPDATE `users`
            SET `name` = ?, `password_hash` = ?, `role` = ?, `courier_code` = ?, `badge` = ?
            WHERE `id` = ?
        ");
        $stmt->execute([$name, $hash, $role, $courierCode, $badge, $id]);
    }
}
