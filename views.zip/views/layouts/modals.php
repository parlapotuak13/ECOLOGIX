<!-- Toast Notification -->
<div id="toast-box" class="fixed top-5 right-4 z-[1200] max-w-sm bg-[#153d32] text-white px-4 py-3 rounded-xl shadow-xl border border-[#b8e071]/50 text-sm font-medium" hidden role="status" aria-live="polite"></div>

<!-- Modal Reset Confirmation -->
  <div id="app-modal" class="fixed inset-0 z-[1150] bg-black/50 backdrop-blur-xs flex items-center justify-center p-4" hidden>
    <div class="surface-card max-w-sm w-full p-6">
      <div class="flex items-center justify-between gap-2 mb-3">
        <h3 class="brand text-xl font-bold text-[#153d32]">Reset Data</h3>
        <button type="button" id="modal-close" class="text-sm font-bold px-2.5 py-1 rounded-lg bg-gray-100 hover:bg-gray-200 cursor-pointer">✕</button>
      </div>
      <p class="text-sm text-[#102e28] mb-5">Kembalikan seluruh data ke pengaturan awal?</p>
      <div class="flex justify-end gap-2">
        <button type="button" id="confirm-cancel-btn" class="btn-secondary text-xs">Batal</button>
        <button type="button" id="confirm-ok-btn" class="btn-primary text-xs bg-red-700 hover:bg-red-800">Reset</button>
      </div>
    </div>
  </div>
