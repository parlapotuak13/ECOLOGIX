<section id="k-panel-verify" class="k-panel" hidden>
          <div class="mb-4">
            <p class="eyebrow">SERAH TERIMA</p>
            <h2 class="brand text-2xl font-bold mt-0.5">Verifikasi OTP</h2>
          </div>

          <div class="grid md:grid-cols-2 gap-4">
            <div class="surface-card p-5 flex flex-col items-center justify-center text-center">
              <h3 class="font-bold text-base mb-3">Kode QR Manifest</h3>
              <div id="k-qr-art" class="qr-grid" aria-label="Kode QR"></div>
              <p class="text-xs font-bold text-[#5e7268] mt-3">ECO-HUB · MERJOSARI · 12 PAKET</p>
            </div>

            <div class="surface-card p-5">
              <h3 class="font-bold text-base">Konfirmasi OTP</h3>
              <div class="my-3 p-3 bg-[#e7f1d8] rounded-xl flex items-center justify-between">
                <span id="k-demo-otp" class="brand tracking-[0.28em] text-2xl sm:text-3xl font-bold text-[#153d32]">----</span>
                <button type="button" id="k-fill-otp-btn" class="text-xs font-bold px-3 py-1.5 rounded-lg bg-[#153d32] text-white cursor-pointer">Salin OTP</button>
              </div>
              <form id="k-otp-form" class="space-y-3">
                <div>
                  <label for="k-otp-input" class="block text-xs font-bold mb-1">Masukkan OTP 4 Digit</label>
                  <input id="k-otp-input" type="text" inputmode="numeric" pattern="[0-9]{4}" maxlength="4" autocomplete="off" required class="field-input text-center text-xl tracking-[0.3em] font-bold" placeholder="••••">
                </div>
                <button id="k-verify-btn" type="submit" class="btn-primary w-full">Verifikasi</button>
              </form>
              <p id="k-otp-msg" class="text-xs font-bold mt-3 min-h-5" role="status"></p>
            </div>
          </div>

          <div class="surface-card p-5 mt-4">
            <div class="flex justify-between items-center mb-2">
              <h3 class="font-bold text-base">Log Serah Terima</h3>
              <strong id="k-verified-count" class="text-sm font-bold text-[#287044]">0 / 12 paket</strong>
            </div>
            <div id="k-log-list" class="text-xs sm:text-sm text-[#5e7268] space-y-1"></div>
          </div>
        </section>
