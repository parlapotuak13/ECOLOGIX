<section id="k-panel-dashboard" class="k-panel">
          <div class="mb-4">
            <p class="eyebrow">OPERASI KURIR · LOWOKWARU</p>
            <h2 class="brand text-2xl font-bold mt-0.5">Dasbor Pengantaran</h2>
          </div>

          <div class="grid lg:grid-cols-[1.35fr_1fr] gap-4">
            <div class="surface-card p-4">
              <div class="flex flex-wrap items-center justify-between gap-2 mb-3">
                <h3 class="font-bold text-base">Peta Rute</h3>
                <span id="k-map-badge" class="text-xs font-semibold px-2.5 py-1 rounded-full bg-[#e7f1d8] text-[#153d32]">Via Hub Merjosari</span>
              </div>
              <div id="k-dash-map" class="map-frame" role="img" aria-label="Peta rute pengiriman"></div>
              <div class="flex flex-wrap gap-4 mt-3 text-xs sm:text-sm">
                <label class="inline-flex items-center gap-2 cursor-pointer">
                  <input id="k-toggle-separate" type="checkbox" checked class="w-4 h-4 accent-gray-600">
                  <span>Rute terpisah (36 km)</span>
                </label>
                <label class="inline-flex items-center gap-2 cursor-pointer">
                  <input id="k-toggle-shared" type="checkbox" checked class="w-4 h-4 accent-green-700">
                  <span>Rute via Hub (26 km)</span>
                </label>
              </div>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div class="surface-card p-4 flex flex-col justify-between">
                <p class="text-xs font-semibold text-[#5e7268]">Jarak Tempuh (VMT)</p>
                <div>
                  <div id="k-vmt-value" class="brand text-2xl sm:text-3xl font-bold text-[#153d32] mt-2">36 → 26 km</div>
                  <p id="k-vmt-sub" class="text-xs text-[#2f7651] font-semibold mt-1">Hemat 10 km</p>
                </div>
              </div>
              <div class="surface-card p-4 flex flex-col justify-between">
                <p class="text-xs font-semibold text-[#5e7268]">Emisi CO₂ Dihemat</p>
                <div>
                  <div id="k-carbon-value" class="brand text-2xl sm:text-3xl font-bold text-[#153d32] mt-2">0,70 kg</div>
                  <p id="k-carbon-sub" class="text-xs text-[#2f7651] font-semibold mt-1">2,52 → 1,82 kg</p>
                </div>
              </div>
              <div class="surface-card p-4 col-span-2">
                <div class="flex items-center justify-between">
                  <p class="text-xs font-semibold text-[#5e7268]">Keterisian Kendaraan</p>
                  <span id="k-fill-tag" class="text-xs font-bold text-[#2f7651]">24 / 30 paket (Sisa 6 paket)</span>
                </div>
                <div id="k-fill-value" class="brand text-2xl sm:text-3xl font-bold text-[#153d32] mt-1">40% → 80%</div>
                <div class="h-2.5 bg-[#e6eee0] rounded-full mt-3 overflow-hidden">
                  <div id="k-fill-bar" class="h-full bg-[#2f7651] rounded-full transition-all duration-500" style="width: 80%"></div>
                </div>
                <p id="k-bagasi-sub" class="text-xs text-[#5e7268] mt-2">Bagasi: 96,0 / 120,0 L (Sisa 24,0 L) · Berat muatan: 27,5 kg</p>
              </div>
            </div>
          </div>

          <div class="surface-card p-4 sm:p-5 mt-4 overflow-x-auto">
            <h3 class="font-bold text-base mb-3">Perbandingan Sebelum vs Sesudah Kolaborasi</h3>
            <table class="w-full text-sm text-left border-collapse">
              <thead>
                <tr class="border-b border-[#dbe4d5] text-[#5e7268]">
                  <th class="py-2.5 px-2 font-semibold">Indikator</th>
                  <th class="py-2.5 px-2 font-semibold">Sebelum</th>
                  <th class="py-2.5 px-2 font-semibold text-[#287044]">Sesudah</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#edf2e8]">
                <tr>
                  <td class="py-2.5 px-2 font-medium">Jarak Tempuh (VMT)</td>
                  <td class="py-2.5 px-2">36 km</td>
                  <td class="py-2.5 px-2 font-bold text-[#287044]">26 km</td>
                </tr>
                <tr>
                  <td class="py-2.5 px-2 font-medium">Emisi CO₂ (CMEM)</td>
                  <td class="py-2.5 px-2" id="k-tbl-co2-before">2,52 kg CO₂</td>
                  <td class="py-2.5 px-2 font-bold text-[#287044]" id="k-tbl-co2">1,82 kg CO₂</td>
                </tr>
                <tr>
                  <td class="py-2.5 px-2 font-medium">Kapasitas Paket (<span class="math-var">V</span><sub>rem</sub>)</td>
                  <td class="py-2.5 px-2">12 / 30 paket (Sisa 18)</td>
                  <td class="py-2.5 px-2 font-bold text-[#287044]" id="k-tbl-cap">24 / 30 paket (Sisa 6)</td>
                </tr>
                <tr>
                  <td class="py-2.5 px-2 font-medium">Biaya per Paket</td>
                  <td class="py-2.5 px-2">Rp 3.750</td>
                  <td class="py-2.5 px-2 font-bold text-[#287044]">Rp 2.858</td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>
