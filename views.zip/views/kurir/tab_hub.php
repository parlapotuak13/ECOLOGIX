<section id="k-panel-hub" class="k-panel" hidden>
          <div class="mb-4">
            <p class="eyebrow">TITIK KONSOLIDASI</p>
            <h2 class="brand text-2xl font-bold mt-0.5">Hub Kel. Merjosari</h2>
          </div>

          <div class="grid sm:grid-cols-3 gap-3 mb-4">
            <div class="surface-card p-4">
              <p class="text-xs text-[#5e7268]">Paket di Hub</p>
              <strong id="k-hub-count" class="brand text-2xl font-bold mt-1 block">0 / 12</strong>
            </div>
            <div class="surface-card p-4">
              <p class="text-xs text-[#5e7268]">Resi Pengirim</p>
              <strong id="k-hub-user-ships" class="brand text-2xl font-bold mt-1 block">1 resi</strong>
            </div>
            <div class="surface-card p-4">
              <p class="text-xs text-[#5e7268]">Status OTP</p>
              <strong id="k-hub-verify-status" class="brand text-xl font-bold mt-1 block text-[#92400e]">Menunggu OTP</strong>
            </div>
          </div>

          <div class="surface-card p-5">
            <div class="flex items-center justify-between mb-3">
              <h3 class="font-bold text-base">Daftar Paket</h3>
              <button type="button" id="k-hub-to-verify" class="text-xs font-bold text-[#153d32] underline cursor-pointer">Verifikasi OTP →</button>
            </div>
            <div id="k-package-list" class="divide-y divide-[#edf2e8]"></div>
          </div>
        </section>
