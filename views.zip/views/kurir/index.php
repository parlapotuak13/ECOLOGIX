<?php
/**
 * Modul Tampilan Utama: Peran Kurir (Eco Hemat & Kilat Raya)
 * Masing-masing tab dipisahkan ke dalam file tersendiri agar mudah diedit.
 */
?>
<div id="view-kurir" class="role-view" hidden>
  <?php require __DIR__ . '/tab_dashboard.php'; ?>
  <?php require __DIR__ . '/tab_tasks.php'; ?>
  <?php require __DIR__ . '/tab_route.php'; ?>
  <?php require __DIR__ . '/tab_hub.php'; ?>
  <?php require __DIR__ . '/tab_verify.php'; ?>
</div>
