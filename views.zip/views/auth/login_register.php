<div id="auth-gate-screen" class="min-h-screen flex items-center justify-center bg-gradient-to-b from-[#153d32] via-[#184539] to-[#0f2e25] p-4">
    <div class="surface-card max-w-md w-full p-6 sm:p-8 text-[#102e28] shadow-2xl">
      <div class="flex items-center gap-3 mb-6">
        <div class="w-11 h-11 rounded-xl bg-[#b8e071] text-[#153d32] grid place-items-center text-2xl font-bold shrink-0">🌿</div>
        <div>
          <h1 class="brand text-2xl font-bold text-[#153d32] leading-none">Eco-LogiX</h1>
          <p class="text-xs text-[#5e7268] mt-1">Sistem Kolaborasi Pengiriman &amp; Optimasi Rute</p>
        </div>
      </div>

      <!-- Tab Masuk vs Daftar -->
      <div class="grid grid-cols-2 gap-2 p-1 bg-[#eef3e8] rounded-xl mb-5">
        <button type="button" id="auth-tab-login" class="py-2.5 px-3 rounded-lg font-bold text-xs sm:text-sm transition cursor-pointer bg-[#153d32] text-white">Masuk</button>
        <button type="button" id="auth-tab-register" class="py-2.5 px-3 rounded-lg font-bold text-xs sm:text-sm transition cursor-pointer text-[#5e7268]">Daftar Akun</button>
      </div>

      <form id="auth-form" class="space-y-4">
        <div>
          <label for="auth-role-select" class="block text-xs font-bold mb-1 text-[#153d32]">Peran Pengguna</label>
          <select id="auth-role-select" class="field-input font-semibold">
            <option value="pengirim">Pengirim</option>
            <option value="kurir_a">Kurir · Eco Hemat</option>
            <option value="kurir_b">Kurir · Kilat Raya</option>
            <option value="vendor">Vendor 3PL</option>
          </select>
        </div>

        <div id="auth-register-fields" hidden>
          <label for="auth-name" class="block text-xs font-bold mb-1 text-[#153d32]">Nama Lengkap / Instansi</label>
          <input id="auth-name" type="text" class="field-input" placeholder="Masukkan nama lengkap">
        </div>

        <div>
          <label for="auth-email" class="block text-xs font-bold mb-1 text-[#153d32]">Email</label>
          <input id="auth-email" type="email" required class="field-input" placeholder="nama@email.com">
        </div>

        <div>
          <label for="auth-pass" class="block text-xs font-bold mb-1 text-[#153d32]">Kata Sandi</label>
          <input id="auth-pass" type="password" required minlength="4" class="field-input" placeholder="Masukkan kata sandi">
        </div>

        <p id="auth-msg" class="text-xs font-bold min-h-4" role="status"></p>

        <button type="submit" id="auth-submit-btn" class="btn-primary w-full py-3 text-sm sm:text-base">Masuk</button>
      </form>
    </div>
  </div>
