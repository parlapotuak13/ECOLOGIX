<?php
declare(strict_types=1);

/**
 * Konstanta Konfigurasi Sistem & Parameter Logistik Eco-LogiX
 */
define('APP_NAME', 'Eco-LogiX');
define('APP_VERSION', '4.1.0');
define('DEFAULT_CITY', 'Kota Malang');

// Kapasitas Maksimal Armada Kurir A (Eco Hemat) & Kurir B (Kilat Raya)
define('COURIER_MAX_PACKAGES', 30);
define('COURIER_BASE_PACKAGES', 12);
define('COURIER_COLLAB_PACKAGES', 12);
define('COURIER_MAX_BAGASI_LITERS', 120.0);
